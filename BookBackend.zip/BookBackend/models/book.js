var db=require('../dbconnection'); //reference of dbconnection.js
 
var book={
 

getAllbook:(callback) => {
 
return db.query("Select * from book_Info",callback);
 
},
 
 getbookById:(id,callback) => {
 
return db.query("select * from book_Info where bid=?",[id],callback);
 },
 
addbook:(booki,callback) => {
 return db.query("Insert into book_Info(title,rate)values(?,?)",
 [booki.title,booki.rate],callback);
},

getlastInsert:(callback) => 
{
    return db.query("select * from book_Info  order by bid desc limit 1",callback);
},
 deletebook:(id,callback) => {
  return db.query("delete from book_Info where bid=?",[id],callback);
 },

 updatebook:(id,book,callback) => {
  return db.query("update book_Info set title=?,rate=? where bid=?",
  [book.title,book.rate,id],callback);
 }
 
};
 module.exports=book;


