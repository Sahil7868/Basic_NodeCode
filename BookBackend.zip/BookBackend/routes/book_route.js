var express = require('express');
var router = express.Router();
var book = require('../models/book');

router.get('/getbook/:id?', (req, res, next) => {

    if (req.params.id) {

        book.getbookById(req.params.id, (err, rows) => {

            if (err) {
                res.json(err);
            }
            else {
                res.json(
                    {
                        message: 'get successfully',
                        data: rows
                    }
                );
            }
        });
    }
    else {
        book.getAllbook((err, rows) => {

            if (err) {
                res.json(err);
            }
            else {
                res.json(
                    {
                        message: 'get successfully',
                        data: rows
                    }
                );
            }

        });
    }
});

router.post('/addbook', (req, res, next) => {

    book.addbook(req.body, (err, result) => {
        if (err) {
            res.json(err);
        }
        else {
            book.getlastInsert((err, row) => {
                if (err) {

                    res.json(err);
                }
                else {
                    res.json(
                        {
                            message: 'added successfully',
                            data: row

                        }
                    );
                }

            });
        }
    });
});

router.delete('/deletebook/:id', (req, res, next) => {

    book.deletebook(req.params.id, (err, count) => {

        if (err) {
            res.json(err);
        }
        else {
            res.json(
                {
                    message: 'delete successfully',
                    data: count
                }
            );
        }

    });
});
router.put('/updatebook/:id', (req, res, next) => {

    book.updatebook(req.params.id, req.body, (err, rows) => {

        if (err) {
            res.json(err);
        }
        else {
            book.getbookById(req.params.id, (err, row) => {
                if (err) {

                    res.json(err);
                }
                else {
                    res.status(200).json(
                        {
                            message: 'updatebook successfully',
                            data: row

                        }
                    );
                }

            });
        }
    });
});

module.exports = router;